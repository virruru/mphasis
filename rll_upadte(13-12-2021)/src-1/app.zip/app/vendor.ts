export class Vendor {
    public ven_id : number;
	public ven_name : string;
	public ven_phn_no: string;
	public ven_username: string;
	public ven_password: string;
	public ven_email: string;

    constructor(){}
}
